from django.contrib import admin
from weather_api.models import WeatherData


# Register your models here.
admin.site.register(WeatherData)